<?php
    $hora = date("M / d / Y");
    echo "{$hora}";
?>